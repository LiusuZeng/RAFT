package Comm;

import java.util.*;
import java.io.*;

public class CommUtil {
	
	public static HashMap<Integer, CommInfo> parse(File src)
	{
		try {
			HashMap<Integer, CommInfo> ret = new HashMap<Integer, CommInfo>();
			ArrayList<CommInfo> raw_ret = splitStr(readByLine(src));
			for(int i = 0; i < raw_ret.size(); i++)
			{
				ret.put(raw_ret.get(i).getEntryID(), raw_ret.get(i));
			}
			//
			return ret;
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
	}
	
	protected static ArrayList<String> readByLine(File src) throws IOException
	{
		ArrayList<String> ret = new ArrayList<String>(0);
		FileReader reader = new FileReader(src);
		BufferedReader br = new BufferedReader(reader);
		String new_entry = null;
		//
		while((new_entry = br.readLine()) != null)
		{
			ret.add(new_entry);
		}
		//
		br.close();
		reader.close();
		//
		return ret;
	}
	
	protected static ArrayList<CommInfo> splitStr(ArrayList<String> src)
	{
		ArrayList<CommInfo> ret = new ArrayList<CommInfo>(0);
		//
		for(int i = 0; i < src.size(); i++)
		{
			String temp = src.get(i);
			String[] para = temp.split(" ");
			if(para.length != 3) throw new IllegalArgumentException();
			//
			int myID = Integer.parseInt(para[0]);
			String myIP = new String(para[1]);
			int myPort = Integer.parseInt(para[2]);
			ret.add(new CommInfo(myID, myIP, myPort));
		}
		//
		return ret;
	}
}
